var nested_iterating = {
  inner: [{
    foo: 'foo',
    inner: [{
      bar: 'bar'
    }]
  }]
};
