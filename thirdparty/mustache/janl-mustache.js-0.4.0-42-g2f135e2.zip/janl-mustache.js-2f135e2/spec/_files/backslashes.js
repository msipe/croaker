var backslashes = {
  value: "\\abc"
};
