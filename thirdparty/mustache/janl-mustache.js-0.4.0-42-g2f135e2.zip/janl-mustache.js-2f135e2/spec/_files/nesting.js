var nesting = {
  foo: [
    {a: {b: 1}},
    {a: {b: 2}},
    {a: {b: 3}}
  ]
};
