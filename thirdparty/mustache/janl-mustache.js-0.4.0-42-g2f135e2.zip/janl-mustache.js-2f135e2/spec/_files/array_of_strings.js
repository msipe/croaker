var array_of_strings = {array_of_strings: ['hello', 'world']};
