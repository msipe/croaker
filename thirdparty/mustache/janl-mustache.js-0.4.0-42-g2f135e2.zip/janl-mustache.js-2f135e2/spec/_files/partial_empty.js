var partial_empty = {
  foo: 1
};
