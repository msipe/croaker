var bug_11_eating_whitespace = {
  tag: "yo"
};
