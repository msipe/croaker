var included_tag = {
  html: "I like {{mustache}}"
};
