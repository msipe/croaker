var changing_delimiters = {
  "foo": "foooooooooooooo",
  "bar":"<b>bar!</b>"
};
