var partial_array_of_partials_implicit = { 
  numbers: ['1', '2', '3', '4']
};
