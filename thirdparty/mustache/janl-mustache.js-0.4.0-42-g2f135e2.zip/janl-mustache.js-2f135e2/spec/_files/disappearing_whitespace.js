var disappearing_whitespace = {
  bedrooms: true,
  total: 1
};
