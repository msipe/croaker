var apostrophe = {'apos': "'", 'control':'X'};
