var empty_list = {
    jobs: []
};
