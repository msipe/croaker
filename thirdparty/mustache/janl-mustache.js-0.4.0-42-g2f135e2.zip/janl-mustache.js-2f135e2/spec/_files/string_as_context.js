var string_as_context = {
    a_string: 'aa',
    a_list: ['a','b','c']
};
