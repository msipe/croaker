var partial_recursion = {
  name: '1',
  kids: [
    {
      name: '1.1',
      children: [
        {name: '1.1.1'}
      ]
    }
  ]
};
