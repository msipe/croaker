var ampersand_escape = {
  message: "Some <code>"
};
