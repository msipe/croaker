var empty_string = {
  description: "That is all!",
  child: {
    description: ""
  }
};
