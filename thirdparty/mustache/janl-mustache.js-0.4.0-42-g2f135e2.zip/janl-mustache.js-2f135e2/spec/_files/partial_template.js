var partial_template = {
  title: function() {
    return "Welcome";
  },
  again: "Goodbye"
};
