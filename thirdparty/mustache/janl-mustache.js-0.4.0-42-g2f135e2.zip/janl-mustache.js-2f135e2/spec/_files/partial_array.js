var partial_array = {
  array: ['1', '2', '3', '4']
};