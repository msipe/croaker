var double_render = {
  foo: true,
  bar: "{{win}}",
  win: "FAIL"
};